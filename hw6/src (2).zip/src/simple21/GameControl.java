package simple21;

import java.util.Scanner;
import java.util.Random;

/**
 * This is a simplified version of a common card game, "21". 
 */
public class GameControl {
    
	/**
	 * Human player.constructor 
	 */
    HumanPlayer human;
    
    /**
     * Computer player.
     */
    ComputerPlayer player1; 
    
    /**
     * Computer player. 3ge construtors
     */
    ComputerPlayer player2;
    
    /**
     * Computer player.
     */
    ComputerPlayer player3;
    
    /** 
     * A random number generator to be used for returning random "cards" in a card deck.
     * */
    Random random = new Random();
      
    /**
     * The main method just creates a GameControl object and calls its run method.
     * @param args Not used.
     */
    public static void main(String args[]) {    
        new GameControl().run();
    }
    
    /**
     * Prints a welcome method, then calls methods to perform each of the following actions:
     * - Create the players (one of them a Human)
     * - Deal the initial two cards to each player
     * - Control the play of the game
     * - Print the final results
     */
    public void run() {
    	
        Scanner scanner = new Scanner(System.in);
        
        // Students: your code goes here.
        System.out.println("Welcome to Simple 21!");
        System.out.println("You'll play against 3 other players(computers)");
        System.out.println("Try to get as close to 21 as possble, without going over");
        System.out.print("What is your name?");
        
        //get humansName
        String humansName = scanner.nextLine();
        //create four players
    	createPlayers(humansName);
    	//deal first two cards
    	deal();
    	//perform new players 
    	while (checkAllPlayersHavePassed() == false) {
    		//do the control play part
    		controlPlay(scanner);
    		System.out.println();
    		
    	}
    	//print results
    	printResults();
    	//print winner
    	printWinner();
    	
        scanner.close();
    }
    
    /**
     * Creates one human player with the given humansName, and three computer players with hard-coded names.
     * @param humansName for human player
     */
    public void createPlayers(String humansName) {
    	
       // Students: your code goes here
    	
    	//new HumanPlayer
    	human = new HumanPlayer(humansName);
    	//new three computer players
    	player1 = new ComputerPlayer("Player 1");
    	player2 = new ComputerPlayer("Player 2");
    	player3 = new ComputerPlayer("Player 3");
    	
    }
    
    /**
     * Deals two "cards" to each player, one hidden, so that only the player who gets it knows what it is, 
     * and one face up, so that everyone can see it. (Actually, what the other players see is the total 
     * of each other player's cards, not the individual cards.)
     */
    public void deal() { 
        // Students: your code goes here.
    	
    	// human first two cards
    	this.human.takeHiddenCard(nextCard());
    	this.human.takeVisibleCard(nextCard());
    	
    	//three computers first two cards
    	this.player1.takeHiddenCard(nextCard());
    	this.player1.takeVisibleCard(nextCard());
    	
    	this.player2.takeHiddenCard(nextCard());
    	this.player2.takeVisibleCard(nextCard());
    	
    	this.player3.takeHiddenCard(nextCard());
    	this.player3.takeVisibleCard(nextCard());
    	
    }
    
    /**
     * Returns a random "card", represented by an integer between 1 and 10, inclusive. 
     * The odds of returning a 10 are four times as likely as any other value (because in an actual
     * deck of cards, 10, Jack, Queen, and King all count as 10).
     * 
     * Note: The java.util package contains a Random class, which is perfect for generating random numbers.
     * @return a random integer in the range 1 - 10.
     */
    public int nextCard() { 
    	// Students: your code goes here.
    	Random random = new Random();
    	//obtain a number between [0-12].
    	int n = random.nextInt(13);
    	//add 1 to the result to get a number from the required range
    	//[1-13].
    	n += 1;
    	//make sure 10 has of odd is four times as other value.
    	if(n>10) {
    		n = 10;
    	}
    	return n;
    }

    /**
     * Gives each player in turn a chance to take a card, until all players have passed. Prints a message when 
     * a player passes. Once a player has passed, that player is not given another chance to take a card.
     * @param scanner to use for user input
     */
    public void controlPlay(Scanner scanner) { 
        // Students: your code goes here.
    	
    	//human part if human player not pass, do following
    	if(human.passed == false) {
    		
    		//get response from human
	    	if (human.offerCard(human, player1, player2, player3, scanner)){
	    		//give new card
	    		human.takeVisibleCard(nextCard());
	    	} else {
	    		//if human passed, print a message
	    		System.out.println(human.name + " passed");
	    	}
    	}
    	//player1 part
    	//not passed
    	if(player1.passed == false) {
    		//get response from human
	    	if (!player1.offerCard(human, player1, player2, player3)){
	    		//give new card
	    		player1.takeVisibleCard(nextCard());
	    	} else {
	    		//if player1 passed, print a message
	    		System.out.println(player1.name + " passed");
	    	}
    	}
    	
    	//player2 same as above
    	if(player2.passed == false) {
    		
	    	if (!player2.offerCard(human, player1, player2, player3)){
	    		player2.takeVisibleCard(nextCard());
	    	} else {
	    		System.out.println(player2.name + " passed");
	    	}
    	}
    	
    	//player3 same as above
    	if(player3.passed == false) {
    		
	    	if (!player3.offerCard(human, player1, player2, player3)){
	    		player3.takeVisibleCard(nextCard());
	    	} else {
	    		System.out.println(player3.name + " passed");
	    	}
    	}
    }
     
    /**
     * Checks if all players have passed.
     * @return true if all players have passed
     */
    public boolean checkAllPlayersHavePassed() {
    	// Students: your code goes here.
    	
    	//create boolean allTrue
    	boolean allTrue = false;
    	//check all passed status
    	if (human.passed && player1.passed && player2.passed && player3.passed) {
    		allTrue = true;
    	}
    	//return allTrue
    	return allTrue;
   
    }
    
    /**
     * Prints a summary at the end of the game.
     * Displays how many points each player had, and if applicable, who won.
     */
    public void printResults() { 
        // Students: your code goes here.
    	System.out.println("Game Over");
    	//print human result
    	System.out.println(human.name+" has "+ human.getScore()+" total point(s)" );
    	//print player1 result
    	System.out.println("player1 "+ player1.getScore()+" total point(s)" );
    	//print player2 result
    	System.out.println("player2 "+ player2.getScore()+" total point(s)" );
    	//print player3 result
    	System.out.println("player3 "+ player3.getScore()+" total point(s)" );
    	
    }

    /**
     * Determines who won the game, and prints the results.
     */
    public void printWinner() { 
    	// Students: your code goes here
    	//human difference between 21 and score
    	int scoreHumanDiff = 21 - this.human.getScore();
    	//player1 difference between 21 and score
    	int scorePlayer1Diff = 21 - this.player1.getScore();
    	//player2 difference between 21 and score
    	int scorePlayer2Diff = 21 - this.player2.getScore();
    	//player3 difference between 21 and score
    	int scorePlayer3Diff = 21 - this.player3.getScore();
    	
    	//create an int to store smallest difference
    	int smallestDiff = 21;
    	//create an boolean to store the tie status
    	boolean tie = false;
    	//create a string to store winner
    	String winner = null;
    	
    	//human part
    	if ((scoreHumanDiff>= 0) && (scoreHumanDiff<smallestDiff)){
    		smallestDiff = scoreHumanDiff;
    		winner = human.name;
    	}
    	//player1 part
    	if ((scorePlayer1Diff>= 0) && (scorePlayer1Diff<smallestDiff)){
    		smallestDiff = scorePlayer1Diff;
    		winner = player1.name;
    	} else if ((scorePlayer1Diff == smallestDiff)) {
    		tie = true;
    	}
    	//player2 part
    	if ((scorePlayer2Diff>= 0) && (scorePlayer2Diff<smallestDiff)){
    		smallestDiff = scorePlayer2Diff;
    		winner = player2.name;
    	} else if ((scorePlayer2Diff == smallestDiff)) {
    		tie = true;
    	}
    	//player3 part
    	if ((scorePlayer3Diff>= 0) && (scorePlayer3Diff<smallestDiff)){
    		smallestDiff = scorePlayer3Diff;
    		winner = player3.name;
    	} else if ((scorePlayer3Diff == smallestDiff)) {
    		tie = true;
    	}
    	//if have winner 
    	if (winner != null) {
    		//do not have tie
    		if (tie != true) {
    			//print the winner message and score
    			System.out.println(winner + " wins with "+(21-smallestDiff)+" point(s)");
    		}
    		else {
    			//print a message indicating the tie
    			
    			System.out.println("Tie, nobody wins.");
    		}
    	}
    	// do not have winner 
    	else {
    		//print an all bust message
    		System.out.println("All bust, nobody wins.");
    	}
    	
    	
    }
}
