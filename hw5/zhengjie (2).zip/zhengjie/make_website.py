import string


def open_read_file(file):
    """
    open and read a file as a list
    :param file: the given file
    :return: a new list
    """
    f = open(file, 'r')

    lines_lst = f.readlines()
    f.close()
    return lines_lst


def get_the_name(lines_lst):
    """
    detech the name
    :param lines_lst: given the list of resume
    :return: name
    """
    name = lines_lst[0].strip()
    # find first character
    first_character = name[0]

    # check whether first character is upper
    if first_character == first_character.upper():
        return str(name)
    else:
        print(" the first line has to be a name with proper capitalization")
        raise RuntimeError


def detecting_email(lines_lst):
    """
    detecting email from the lines
    :param lines_lst: original list
    :return: email
    """

    # empty email list
    email = []
    flag = 0
    digits = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
    for line in lines_lst:
        if '@' in line:
            # find the email line
            email = line.rstrip()
            # check email list .com or .edu

            if email[-4:] == '.com' or email[-4:] == '.edu':
                pass
            else:
                print("the email should end with .com or .edu ")
                flag = 1

            # check if the email have digit
            for i in digits:
                if str(i) not in email:
                    pass
                else:
                    print("the email should not have digits or numbers")
                    flag = 1

    # if flag equals 1, this is the not valid circumstances
    if flag == 1:
        print("This is not a valid email")
        # return empty
        return ''
    else:
        return str(email)


def detecting_courses(lines_lst):
    """
    detect courses
    :param lines_lst: original lines
    :return: courses
    """
    # find courses
    for line in lines_lst:
        if 'Courses' in line:
            courses = line.strip()

    # without title courses the remaining thing
    courses_withoutC = courses[8:]

    # find all upper and lower alphabet
    alphabet_upper = string.ascii_uppercase
    alphabet_lower = string.ascii_lowercase
    alphabet = list(alphabet_lower + alphabet_upper)

    # find the index of first real course
    for char in courses_withoutC:
        if char in alphabet:
            m = courses_withoutC.index(char)
            break

    # use the index to slice the courses list
    courses_cleaned = courses_withoutC[m:]
    courses_output = courses_cleaned.strip()

    return courses_output


def detecting_projects(lines_lst):
    '''
    find the projrets list
    :param lines_lst: orginal list
    :return: list of projects
    '''
    flag = 0
    project = []
    for line in lines_lst:
        # find the project and start to store it
        if 'Projects' in line:
            flag = 1
        # find the end of projects and stop to store it
        if '----------' in line:
            flag = 0
        # do not store the '' empty line
        if (flag == 1) & (line != ''):
            project.append(line.rstrip())

    # return projects without the title
    print(project[1:])
    return project[1:]


def surround_block(tag, text):
    '''o This function surrounds the given text with the given HTML tag and returns the string
    o
    For example, surround_block(‘h1’, ‘The Beatles’) would return ‘ < h1 > The Beatles < / h1 >’
    '''
    html = ('<{}>{}</{}>'.format(tag, text, tag))
    return html


def create_email_link(email_address):
    """
    o This function creates an email link with the given email_address
    o To cut down on spammers harvesting the email address from your webpage,
    this function should display the email address with an [aT] instead of an @
    o For example, create_email_link(‘tom@seas.upenn.edu’) would return
    ‘<a href="mailto:tom@seas.upenn.edu"> tom[aT]seas.upenn.edu</a>’
    """
    if "@" in email_address:
        email_replace = email_address.replace("@", "[aT]")
    else:
        email_replace = email_address
    email_link = '<a href="mailto:{}"> {}</a>'.format(email_address, email_replace)

    print(email_link)
    return email_link


def write_projects_html(projects):
    """
    write projects in html format properly
    :param projects: initial project list
    :return: html format final_projects
    """
    # new project list
    project_list = []
    # write the html project header
    projects_header = surround_block('h2', 'Projects')
    # get each project and surround block
    for project in projects:
        project_each = surround_block('li', project)
        project_list.append(project_each)
    # turn it into str
    project_str = ''.join(project_list)
    # add surround block
    projects_u1 = surround_block('ul', project_str)
    # add together
    final_projects = surround_block('div', projects_header + projects_u1)
    return final_projects


def write_basic_information(name, email_address):
    """
    write basic information in html format
    :param name: the list of name
    :param email_address: the list of detected email address
    :return: html section of basic informaiton
    """
    # making name_html
    name_html = surround_block('h1', name)
    # making email html
    email_html = "<p>Email: {}</p>".format(create_email_link(email_address))
    # add name and email together
    basic_information = surround_block('div', name_html + email_html)
    basic = '<div id="page-wrap">' + basic_information
    return basic


def write_courses(courses):
    """
    write the courses in the html format
    :param courses: original courses list
    :return: html format courses
    """
    # surround block of span
    middle = surround_block('span', courses)

    # courses with title in html format
    courses_html = '<div><h3>Courses</h3>' + middle + '</div>'

    return courses_html


def export_html(file, filename):
    """

    :param file: list content to add in a file
    :param filename: new out file
    :return:
    """
    filename += ".html"
    # file our
    fout = open(filename, 'w')
    # add information in file out
    fout.writelines(file)
    # close the output file
    fout.close()


def main():
    # read the resume.txt
    lines_lst = open_read_file('resume.txt')
    # get the name
    name = get_the_name(lines_lst)
    # get the email address
    email_address = detecting_email(lines_lst)
    # get courses
    courses = detecting_courses(lines_lst)
    # get projects
    projects = detecting_projects(lines_lst)
    # open and read the resume template html file
    html_lines_lst = open_read_file('resume_template.html')
    # store last two line of html
    html_last_two = html_lines_lst[-2:]
    # store html content without last two lines
    html = html_lines_lst[0:-2]

    # add basic information
    html.append(write_basic_information(name, email_address))
    # add projects
    html.append(write_projects_html(projects))
    # add courses
    html.append(write_courses(courses))
    # add the ending
    html.append("</div>")
    html.extend(html_last_two)
    # export the file with name resume
    export_html(html, "resume")


if __name__ == '__main__':
    main()
