import unittest
from textwrap import wrap

from make_website import *


class Test_Make_Website(unittest.TestCase):

    def setUp(self):
        self.resume = open_read_file("resume.txt")

    def test_get_the_name(self):
        """
        unit test for detect_name
        """
        # first use the resume.txt to check the function
        self.assertEqual("Jane Yang", get_the_name(self.resume))

        # first letter capitalized
        list0 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses: Programming, Finance', 'Projects', 'Project 1',
                 'Project 2', '----------']
        # test run time error
        list1 = ['jane Yang', 'zhengjie@sas.upenn.edu', 'Courses: Programming, Finance', 'Projects', 'Project 1',
                 'Project 2', '----------']

        self.assertEqual('Jane Yang', get_the_name(list0))
        self.assertRaises(RuntimeError, get_the_name, list1)

    def test_detecting_email(self):
        """
        unit test for detect_email
        """
        # first use the resume.txt to check the function
        self.assertEqual("zhengjie@sas.upenn.edu", detecting_email(self.resume))

        lst0 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses: c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']  # correct format
        lst1 = ['Jane Yang', 'zhengjie33@sas.upenn.edu', 'Courses: c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']  # email address with number
        lst3 = ['Jane Yang', 'zhengjie@sas.upenn.qq', 'Courses: c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']  # not ending with .com or .edu

        self.assertEqual('zhengjie@sas.upenn.edu', detecting_email(lst0))
        self.assertEqual('', detecting_email(lst1))
        self.assertEqual('', detecting_email(lst3))

    def test_detecting_courses(self):
        """unit test for detect_courses
        """
        # first use the resume.txt to check the function
        self.assertEqual("Programming Languages and Techniques, Corporate Finance, Engineering Economics",
                         detecting_courses(self.resume))
        # check various situation

        # with ': 'before first course
        lst0 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses: c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']
        # with '  'before first course
        lst1 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses  c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']
        # with '@' before first course
        lst2 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses%c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']
        # courses start with uppercase
        lst3 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses: C1,C2,C3', 'Projects', 'p1', 'p2',
                '----------']

        self.assertEqual('c1,c2,c3', detecting_courses(lst0))
        self.assertEqual('c1,c2,c3', detecting_courses(lst1))
        self.assertEqual('c1,c2,c3', detecting_courses(lst2))
        self.assertEqual('C1,C2,C3', detecting_courses(lst3))

    def test_detecting_projects(self):
        """
        unit test for detect_projects
        The data type of projects is list
        """
        # first use the resume.txt to check the function
        self.assertEqual([
                             'No project but still need to write the first one here, Philadelphia, PA, USA - Project manager, codified the assessment and mapped it to the CancerDetector ontology. Member of the UI design team, designed the portfolio builder UI and category search pages UI. Reviewed existing rank order and developed new search rank order approach.',
                             'Second project can I just use the template like the following Biomedical Imaging - Developed a semi-automatic image mosaic program based on SIFT algorithm (using Matlab)',
                             'I cannot come up with more projects, hhh'],
                         detecting_projects(self.resume))

        # test others

        # normal case
        lst0 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses: c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------']
        # with blank
        lst1 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses  c1,c2,c3', 'Projects', 'p1', '', 'p2',
                '----------']  # has blank line
        # with more complicated thing at end
        lst2 = ['Jane Yang', 'zhengjie@sas.upenn.edu', 'Courses@c1,c2,c3', 'Projects', 'p1', 'p2',
                '----------!#', 'NAME OR SOMETHING']  # with additional characters in ending

        self.assertEqual(['p1', 'p2'], detecting_projects(lst0))
        self.assertEqual(['p1', 'p2'], detecting_projects(lst1))
        self.assertEqual(['p1', 'p2'], detecting_projects(lst2))

    def test_surround_block(self):
        """
        test the function surround block

        :return:the html if block
        """
        self.assertEqual('<h1>The Beatles</h1>', surround_block('h1', 'The Beatles'))

    def test_create_email_link(self):
        """
        unit test for create email link
        :return:html email link
        """

        # check the resume txt
        self.assertEqual('''<a href="mailto:zhengjie@sas.upenn.edu"> zhengjie[aT]sas.upenn.edu</a>''',
                         create_email_link(detecting_email(self.resume)))
        # check other circumstances
        self.assertEqual('<a href="mailto:tom@seas.upenn.edu"> tom[aT]seas.upenn.edu</a>',
                         create_email_link('tom@seas.upenn.edu'))

    def test_write_projects_html(self):
        """unit test for html project
        """
        # check the resume.txt project
        self.assertEqual(
            "<div><h2>Projects</h2><ul><li>No project but still need to write the first one here, Philadelphia, PA, USA - Project manager, codified the assessment and mapped it to the CancerDetector ontology. Member of the UI design team, designed the portfolio builder UI and category search pages UI. Reviewed existing rank order and developed new search rank order approach.</li><li>Second project can I just use the template like the following Biomedical Imaging - Developed a semi-automatic image mosaic program based on SIFT algorithm (using Matlab)</li><li>I cannot come up with more projects, hhh</li></ul></div>",
            (write_projects_html(detecting_projects(self.resume))))

        # check in another way
        self.assertEqual("<div><h2>Projects</h2><ul><li>p1</li><li>p2</li></ul></div>",
                         write_projects_html(['p1', 'p2']))

    def test_write_basic_information(self):
        """unit test for write html basic info
        """
        self.assertEqual(
            '''<div id="page-wrap"><div><h1>Jane Yang</h1><p>Email: <a href="mailto:zhengjie@sas.upenn.edu"> zhengjie[aT]sas.upenn.edu</a></p></div>''',
            write_basic_information(get_the_name(self.resume),detecting_email(self.resume)))

        self.assertEqual(
            '''<div id="page-wrap"><div><h1>Brandon</h1><p>Email: <a href="mailto:Email: lbrandon@wharton.upenn.edu"> Email: lbrandon[aT]wharton.upenn.edu</a></p></div>''',
            write_basic_information("Brandon", "Email: lbrandon@wharton.upenn.edu"))

    def test_write_courses(self):
        """unit test for write html courses
        """
        # check the txt itself
        self.assertEqual(
            "<div><h3>Courses</h3><span>Programming Languages and Techniques, Corporate Finance, Engineering Economics</span></div>",
            write_courses(detecting_courses(self.resume)))
        # check in another way

        self.assertEqual("<div><h3>Courses</h3><span>c1, c2</span></div>", write_courses('c1, c2'))


unittest.main()
